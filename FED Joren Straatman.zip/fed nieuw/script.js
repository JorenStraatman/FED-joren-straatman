
function load() {
    document.getElementById("like").addEventListener("click", like);
}

function like() {
    
    if(!document.querySelector(".favorite").classList.contains('active')) {
       document.querySelector(".favorite").classList.add('active');
        console.log('voeg toe');
    } else {
       document.querySelector(".favorite").classList.remove('active');
        console.log('verwijder');
    }
    
}

